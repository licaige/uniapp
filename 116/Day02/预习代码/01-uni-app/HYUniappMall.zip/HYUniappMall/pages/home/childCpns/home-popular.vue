<template>
	<view class="popular">
		<image class="image" mode="widthFix" src="../../../static/images/home/recommend_bg.jpg"></image>
	</view>
</template>

<script>
</script>

<style lang="scss">
	.popular {
		.image {
			width: 100%;
		}
	}
</style>
